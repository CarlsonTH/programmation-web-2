//----------------------------------------------------------------
//                        Votre code ici
//----------------------------------------------------------------


    function afficher() {
        alert("Bon examen !");
    }
    var bouton = document.getElementById("greetings");
    bouton.addEventListener("click", afficher);
