function delete1() {
    document.getElementById('delete1').textContent = '';
  }
  
  function delete2() {
    document.querySelector('.delete2').textContent = '';
  }
  
  function delete3() {
    document.querySelector('[name="delete3"]').textContent = '';
  }
  